﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HugoLandEditeur
{
    public enum TypeTile
    {
        ObjetMonde = 0,
        Monstre = 1,
        Item = 2,
        ClasseHero = 3,
        Tile = 4
    }

}
